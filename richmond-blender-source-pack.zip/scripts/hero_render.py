import bpy,math
from pathlib import Path
from mathutils import Vector
root=Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-04-Panel-Scenarios.blend'))
s=bpy.context.scene
for c in bpy.data.collections:
    if c.name.startswith('PV '):c.hide_render=c.hide_viewport=not c.name.startswith('PV 50')
    if c.name.startswith('07 Reserved access'):c.hide_render=True
camdata=bpy.data.cameras.new('Hero — pedestrian eye height 1.7m')
cam=bpy.data.objects.new(camdata.name,camdata);s.collection.objects.link(cam)
cam.location=(-42,-58,1.7);target=Vector((0,-1,8.8));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
camdata.type='PERSP';camdata.lens=38;camdata.clip_end=1500;s.camera=cam
ground=bpy.data.objects.get('Presentation ground')
if ground:ground.dimensions=(600,600,.5)
s.world.use_nodes=True
bg=s.world.node_tree.nodes.get('Background');bg.inputs['Color'].default_value=(.67,.78,1,1);bg.inputs['Strength'].default_value=.55
sun=next(o for o in s.objects if o.type=='LIGHT')
sun.rotation_euler=(math.radians(35),math.radians(-35),math.radians(-30));sun.data.energy=2.5;sun.data.angle=math.radians(2)
sun.name='Hero presentation sunlight — not a study timestamp'
s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=True
s.render.resolution_x=2400;s.render.resolution_y=1500;s.render.resolution_percentage=100
s.render.image_settings.file_format='PNG'
s['hero_status']='Concept hero; street camera 1.7m, 90 panels enabled; parapets realistically obscure roof panels'
s['hero_lighting']='Presentation lighting; not the geolocated sun-study setup'
s.render.filepath=str(root/'renders/08-street-hero.png')
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-08-Hero.blend'))
bpy.ops.render.render(write_still=True)
print('HERO_COMPLETE',flush=True)
