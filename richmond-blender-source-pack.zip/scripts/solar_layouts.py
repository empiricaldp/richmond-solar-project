import bpy, math, json
from pathlib import Path
from mathutils import Vector
root=Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-03-Facade.blend'))
scene=bpy.context.scene
for o in scene.objects:
    if o.name.startswith(('Projecting precast dividing wall','Corner projecting blade')):
        o.dimensions.z=18.0;o.location.z=9.0
W,L,P=1.134,1.762,440
tilt=math.radians(10); footprint=W*L*math.cos(tilt)
# Rectangles are (xmin,xmax,ymin,ymax), in local building coordinates.
roof=(-6.9,6.9,-28.05,28.05); inner=(-5.9,5.9,-27.05,27.05)
zones=json.loads((root/'notes/obstacle-envelopes.json').read_text())
equipment=[(x-w/2-.5,x+w/2+.5,y-l/2-.5,y+l/2+.5) for _,x,y,w,l,h in zones]
paths=[(-5.1,-3.9,-27.05,27.05),(-5.1,5.9,-.6,.6),(-5.1,5.9,12.4,13.6),(-5.1,5.9,-15.6,-14.4)]
blocked=equipment+paths
def overlap(a,b):return a[0]<b[1]-1e-8 and a[1]>b[0]+1e-8 and a[2]<b[3]-1e-8 and a[3]>b[2]+1e-8
def union_area(rects,bounds):
    rects=[(max(a,bounds[0]),min(b,bounds[1]),max(c,bounds[2]),min(d,bounds[3])) for a,b,c,d in rects]
    rects=[r for r in rects if r[1]>r[0] and r[3]>r[2]]
    xs=sorted(set([bounds[0],bounds[1]]+[v for r in rects for v in r[:2]]));area=0
    for a,b in zip(xs,xs[1:]):
        spans=sorted((r[2],r[3]) for r in rects if r[0]<(a+b)/2<r[1]);length=0;end=-1e20
        for lo,hi in spans:length+=max(0,hi-max(lo,end));end=max(end,hi)
        area+=(b-a)*length
    return area
usable=(inner[1]-inner[0])*(inner[3]-inner[2])-union_area(blocked,inner)
# Search grid offsets only; no claim that this is the maximum feasible layout.
dx=W+.025;dy=L*math.cos(tilt)+.45
best=[]
for xi in range(12):
    for yi in range(12):
        candidates=[];x=inner[0]+W/2+xi*dx/12
        while x+W/2<=inner[1]+1e-8:
            y=inner[2]+L*math.cos(tilt)/2+yi*dy/12
            while y+L*math.cos(tilt)/2<=inner[3]+1e-8:
                r=(x-W/2,x+W/2,y-L*math.cos(tilt)/2,y+L*math.cos(tilt)/2)
                if not any(overlap(r,b) for b in blocked):candidates.append((x,y,r))
                y+=dy
            x+=dx
        if len(candidates)>len(best):best=candidates
best.sort(key=lambda p:(-p[1],p[0]))
for i,(_,_,r) in enumerate(best):
    assert not any(overlap(r,b) for b in blocked)
    assert not any(overlap(r,q[2]) for q in best[:i])
def material(name,c,metal=0):
    m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=.28
    return m
blue=material('PV dark blue cells',(.018,.048,.095),.25)
silver=material('PV frame',(.35,.39,.42),.7)
green=material('Reserved access — illustrative',(.12,.52,.32))
def collection(name):
    c=bpy.data.collections.new(name);scene.collection.children.link(c);return c
access=collection('07 Reserved access — conceptual, roof access origin unverified')
# Direct mesh creation avoids expensive repeated operator updates.
def box(name,loc,dims,m,c):
    x,y,z=(v/2 for v in dims)
    verts=[(-x,-y,-z),(-x,-y,z),(-x,y,-z),(-x,y,z),(x,-y,-z),(x,-y,z),(x,y,-z),(x,y,z)]
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]);mesh.materials.append(m)
    o=bpy.data.objects.new(name,mesh);c.objects.link(o);o.location=loc;return o
for i,(a,b,c,d) in enumerate(paths):
    box(f'Concept access route {i+1}',((a+b)/2,(c+d)/2,18.061),(b-a,d-c,.012),green,access)
# Routes overlapping obstacle envelopes are not physical walkways: mask those segments.
for o in list(access.objects):bpy.data.objects.remove(o,do_unlink=True)
for i,(a,b,c,d) in enumerate(paths):
    xs=sorted(set([a,b]+[max(a,min(b,v)) for r in equipment for v in r[:2]]))
    ys=sorted(set([c,d]+[max(c,min(d,v)) for r in equipment for v in r[2:]]))
    for x0,x1 in zip(xs,xs[1:]):
        for y0,y1 in zip(ys,ys[1:]):
            r=(x0,x1,y0,y1)
            if not any(overlap(r,e) for e in equipment):box('Reserved access segment',((x0+x1)/2,(y0+y1)/2,18.065),(x1-x0,y1-y0,.02),green,access)
collections=[];results=[]
for target in (.2,.5,.8):
    desired=math.floor(target*usable/footprint)
    n=min(desired,len(best));c=collection(f'PV {int(target*100)} percent target — {n} panels');collections.append(c)
    for i,(x,y,_) in enumerate(best[:n]):
        center=Vector((x,y,18.30+L*math.sin(tilt)/2))
        o=box(f'PV {int(target*100)}-{i+1:03} — 440 W',center,(W,L,.03),silver,c);o.rotation_euler.x=-tilt
        cell=box('Module glass and cells',center+Vector((0,math.sin(tilt)*.018,math.cos(tilt)*.018)),(W-.035,L-.035,.009),blue,c);cell.rotation_euler.x=-tilt
        for yy in (-L*.31,L*.31):
            z=center.z-math.sin(tilt)*yy-.05
            box('Concept support rail',(x,y+yy*math.cos(tilt),z),(W+.03,.045,.055),silver,c)
    results.append(dict(target_percent=int(target*100),requested_panels=desired,panels=n,dc_kw=round(n*P/1000,2),usable_coverage_percent=round(n*footprint/usable*100,2),gross_coverage_percent=round(n*footprint/(13.8*56.1)*100,2),target_reached=desired<=len(best)))
summary=dict(panel='Trina Vertex S+ TSM-440NEG9R.28, representative Australian-market assumption',watts=P,dimensions_m=[L,W,.03],tilt_deg=10,usable_area_m2=round(usable,2),gross_model_area_m2=round(13.8*56.1,2),grid_capacity_panels=len(best),cases=results)
notes='''STAGE 04 — CONCEPT PANEL LAYOUTS
Panel: representative Trina Vertex S+ TSM-440NEG9R.28, 440 W, 1762 x 1134 x 30 mm.
Source: https://static.trinasolar.com/sites/default/files/Vertex%20S%2B_NEG9R.28_EN_2024_Aus_B_web.pdf
These are project assumptions, not an Australian-standard or approved installation.
Roof edge reserve: 1 m. Equipment clearance: 0.5 m. Access reserves: 1.2 m.
10 degree tilt toward local +Y; true azimuth and solar orientation still unverified.
0.45 m projected gap between rows is a packing assumption, not a verified shading clearance.
Coverage means projected panel footprint / usable area after reserves. Also report gross coverage.
Usable area is calculated by rectangle union, avoiding double subtraction of overlapping exclusions.
Equipment footprints/heights remain estimates. Access route origin and continuity to all equipment
are unverified; reserved strips are interrupted by equipment exclusions. A verified access plan,
structural/wind design, mounting/ballast design, electrical design, shading and site assessment
are still required. This is not the proven maximum capacity of the real roof.
No yearly generation, compliance, quote or electrical load coverage is claimed.
'''
(root/'notes/solar-assumptions.txt').write_text(notes)
(root/'notes/solar-layout-results.json').write_text(json.dumps(summary,indent=2))
bpy.data.texts.new('SOLAR ASSUMPTIONS AND RESULTS').write(notes+'\n'+json.dumps(summary,indent=2))
scene['solar_layout_status']='CONCEPT ONLY; access origin and true azimuth unverified'
scene.camera=bpy.data.objects['Roof plan'];scene.camera.data.ortho_scale=65
scene.render.engine='BLENDER_WORKBENCH';scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL'
scene.display.shading.show_shadows=False;scene.display.shading.show_cavity=True
scene.render.resolution_x=850;scene.render.resolution_y=1500
for i,result in enumerate(results):
    for j,c in enumerate(collections):c.hide_render=c.hide_viewport=(i!=j)
    scene.render.filepath=str(root/f'renders/04-layout-{result["target_percent"]}.png');bpy.ops.render.render(write_still=True)
for j,c in enumerate(collections):c.hide_render=c.hide_viewport=(j!=1)
scene.render.engine='CYCLES';scene.cycles.samples=24
scene.camera=bpy.data.objects['Massing overview'];scene.render.resolution_x=1500;scene.render.resolution_y=1100
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-04-Panel-Scenarios.blend'))
scene.render.filepath=str(root/'renders/04-solar-overview.png');bpy.ops.render.render(write_still=True)
print(json.dumps(summary))
