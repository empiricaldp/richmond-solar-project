import bpy
from pathlib import Path
root=Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-08-Hero.blend'))
s=bpy.context.scene;s.camera=bpy.data.objects['Massing overview']
s.camera.data.ortho_scale=82
s.render.resolution_x=2000;s.render.resolution_y=1400;s.cycles.samples=32
pv=[c for c in bpy.data.collections if c.name.startswith('PV ')]
active=next(c for c in pv if c.name.startswith('PV 50'))
assert len([o for o in active.objects if o.name.startswith('PV 50-')])==90
for c in pv:c.hide_render=True;c.hide_viewport=True
s.render.filepath=str(root/'renders/09-aerial-before.png');bpy.ops.render.render(write_still=True)
active.hide_render=False;active.hide_viewport=False
s.render.filepath=str(root/'renders/09-aerial-after.png');bpy.ops.render.render(write_still=True)
s['aerial_comparison']='Same camera, resolution, lighting, building and roof obstacles. Only the 90-panel collection changes visibility.'
s['comparison_note']='Both images are concept-model renders, not photographs of the property.'
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-09-Aerial-Comparison.blend'))
print('AERIAL_PAIR_COMPLETE',flush=True)
