import bpy,json,struct
from pathlib import Path
root=Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-09-Aerial-Comparison.blend'))
scene=bpy.context.scene
bpy.ops.object.select_all(action='DESELECT')
chosen=[]
for o in scene.objects:
    if o.type!='MESH':continue
    if o.name=='Presentation ground':continue
    if any(c.name.startswith(('05 Presentation','07 Reserved access')) for c in o.users_collection):continue
    pv=[c for c in o.users_collection if c.name.startswith('PV ')]
    if pv and not any(c.name.startswith('PV 50') for c in pv):continue
    o.hide_set(False);o.select_set(True);chosen.append(o)
panels=[o for o in chosen if o.name.startswith('PV 50-')]
assert len(panels)==90
scene['export_status']='Approximate Richmond solar concept; 90 panels, 39.6 kW DC'
path=root/'exports/Richmond-Solar-90-Panels.glb'
bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_cameras=False,export_lights=False,export_extras=True)
blob=path.read_bytes();magic,version,length=struct.unpack_from('<4sII',blob)
assert magic==b'glTF' and version==2 and length==len(blob)
json_len,json_type=struct.unpack_from('<II',blob,12);doc=json.loads(blob[20:20+json_len])
assert not doc.get('cameras')
assert all('uri' not in b for b in doc.get('buffers',[]))
expected=len(panels)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(path))
actual=sum(o.name.startswith('PV 50-') for o in bpy.context.scene.objects)
assert actual==expected,(actual,expected)
mesh_objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
assert mesh_objects and all(all(abs(v)<1000 for v in o.location) for o in mesh_objects)
report={'file':path.name,'format':'glTF 2.0 binary','bytes':len(blob),'panels_reimported':actual,'dc_kw':39.6,'imported_mesh_objects':len(mesh_objects),'external_buffers':False,'units':'metres','axis':'glTF Y-up; Blender conversion handled by exporter','scope':'Building, facade, approximate rooftop equipment, 90 panels and illustrative landscaping. No ground plane, cameras, lights or unused panel scenarios.','limits':'Geometry and equipment remain approximate. Not a surveyed or installation-ready model. Sun-study animation is separate.'}
(root/'exports/GLB-export-notes.json').write_text(json.dumps(report,indent=2))
(root/'exports/GLB-README.txt').write_text('RICHMOND SOLAR - WEBSITE MODEL\n\nOpen Richmond-Solar-90-Panels.glb in a glTF-compatible 3D viewer.\nThe file contains the building with 90 panels (39.6 kW DC).\nMaterials and geometry are embedded; no separate texture folder is required.\nUse metres. Web viewers normally frame and light the model themselves.\nThis is an approximate concept model, not installation documentation.\nThe summer/winter sun-study video remains a separate MP4.\nThe original editable Blender files are preserved in the blender folder.\n')
print('GLB_VERIFIED '+json.dumps(report),flush=True)
