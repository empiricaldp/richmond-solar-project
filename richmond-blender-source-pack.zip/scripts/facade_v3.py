import bpy, math, random
from pathlib import Path
from mathutils import Vector
root=Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-02-Massing.blend'))
scene=bpy.context.scene
for c in list(bpy.data.collections):
    if c.name.startswith('02 Facade'):
        for o in list(c.objects): bpy.data.objects.remove(o,do_unlink=True)
        bpy.data.collections.remove(c)
def mat(name,c,rough=.5,metal=0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*c,1); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*c,1)
    p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
    return m
white=mat('Ivory precast concrete',(.71,.69,.63),.7)
stone=mat('Balcony soffit and slabs',(.55,.54,.50),.8)
frame=mat('Charcoal aluminium',(.045,.05,.052),.28,.65)
glass=mat('Blue grey glazing',(.16,.25,.30),.18,.35)
p=glass.node_tree.nodes.get('Principled BSDF');p.inputs['Transmission Weight'].default_value=.25
timber=mat('Warm timber toned ground panels',(.27,.13,.058),.65)
joint=mat('Precast shadow joints',(.28,.28,.26),.9)
green=mat('Planting',(.105,.19,.07),.95)
soil=mat('Planter soil',(.07,.055,.035),1)
def coll(name):
    c=bpy.data.collections.new(name);scene.collection.children.link(c);return c
fac=coll('02 Reference-led facade — spacing and depths estimated')
land=coll('06 Indicative ground landscaping')
def box(name,pos,dim,m,c=fac,bevel=0):
    bpy.ops.mesh.primitive_cube_add(size=1,location=pos);o=bpy.context.object;o.name=name;o.dimensions=dim
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    for old in list(o.users_collection):old.objects.unlink(o)
    c.objects.link(o);o.data.materials.append(m)
    if bevel:
        b=o.modifiers.new('Soft construction edges','BEVEL');b.width=bevel;b.segments=2
        o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return o
body=next(o for o in scene.objects if o.name.startswith('Building shell'))
body.dimensions=(9.3,56.1,18);body.location.z=9
body.name='Six-level core — 18 m height ASSUMED'
body['height_status']='Six apparent levels; 3 m per level assumed, not surveyed'
body.data.materials.clear();body.data.materials.append(white)
for o in scene.objects:
    if o.name.startswith(('Roof surface','Parapet','O0','O10')):o.location.z+=3
for o in bpy.data.collections['04 Obstacle envelopes — position and size approximate'].objects:
    o.data.materials.clear();o.data.materials.append(bpy.data.materials['Light roof membrane'])
# Seven repeated bays are an approximation; west-side details follow inspected street imagery.
bay=56.1/7
for side in (-1,1):
    prefix='Street' if side==-1 else 'Courtyard — inferred'
    for k in range(7):
        y=-28.05+(k+.5)*bay
        for level in range(6):
            z=level*3
            # Recessed wall and framed sliding doors sit 2 m behind the outer balcony edge.
            box(f'{prefix} recessed glazing L{level+1}',(side*4.66,y,z+1.5),(.06,bay-1.4,2.4),glass)
            for dy in (-2.9,-1.0,1.0,2.9):box('Sliding door mullion',(side*4.72,y+dy,z+1.5),(.08,.055,2.4),frame)
            for dz in (.31,2.69):box('Door frame rail',(side*4.72,y,z+dz),(.08,bay-1.35,.055),frame)
            box('Balcony floor slab',(side*5.7,y,z+.13),(2.4,bay-.35,.26),stone,bevel=.025)
            if level>0:
                box('Solid pale balcony fascia',(side*6.83,y,z+.49),(.17,bay-.40,.72),white,bevel=.018)
                box('Glazed balcony balustrade',(side*6.82,y,z+1.00),(.035,bay-.5,.38),glass)
                box('Slim balustrade top rail',(side*6.84,y,z+1.2),(.065,bay-.45,.045),frame)
                for dy in (-2.0,0,2.0):box('Balustrade post',(side*6.85,y+dy,z+1.0),(.04,.035,.4),frame)
            else:
                box('Ground timber screen',(side*5.8,y+bay*.34,1.55),(2.05,.16,2.7),timber)
                for zt in [j*.18+.3 for j in range(15)]:box('Timber horizontal joint',(side*5.8,y+bay*.34,zt),(2.06,.17,.012),joint)
        # Tall fins create the strong vertical rhythm visible in the reference.
        box('Projecting precast dividing wall',(side*5.78,y-bay/2+.16,9.18),(2.3,.28,18.36),white,bevel=.022)
        for z in (3,6,9,12,15):box('Fin horizontal panel joint',(side*6.942,y-bay/2+.16,z),(.008,.281,.018),joint)
    for y in (-27.91,27.91):box('Corner projecting blade',(side*5.78,y,9.18),(2.3,.28,18.36),white,bevel=.025)
# End elevations: three upper window columns plus a narrow slot near the street corner.
for end in (-1,1):
    y=end*28.08
    box('Pale end wall',(0,y,9),(13.8,.20,18),white,bevel=.025)
    for level in range(1,6):
        z=level*3+1.5
        for x in (-.7,1.8,4.3):
            box('End elevation dark window reveal',(x,y+end*.115,z),(1.08,.06,1.95),frame)
            box('End elevation glazing',(x,y+end*.15,z),(.90,.02,1.77),glass)
            box('End window transom',(x,y+end*.18,z-.15),(.94,.04,.055),frame)
        box('Narrow end wall slot',(-4.85,y+end*.12,z),(.48,.05,1.95),frame)
    for z in (3,6,9,12,15):box('End precast horizontal joint',(0,y+end*.12,z),(13.75,.008,.018),joint)
    for x in (-2.5,2.5):box('End precast vertical joint',(x,y+end*.12,9),(.015,.008,17.9),joint)
    box('Ground end timber wall',(0,y+end*.13,1.4),(13.2,.08,2.65),timber)
    for x in (-2,2):box('Ground end glazing',(x,y+end*.20,1.4),(2.4,.05,2.4),glass)
# Landscaping stays low so the architecture remains legible.
box('Street footpath',(-9.6,0,-.035),(5.5,65,.15),stone,land)
random.seed(17)
for k in range(7):
    y=-24+k*8
    box('Raised street planter',(-7.65,y,.4),(1.2,5.8,.8),white,land,bevel=.04)
    box('Soil',(-7.65,y,.815),(1.03,5.55,.05),soil,land)
    for j in range(7):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=(-7.65+random.uniform(-.2,.2),y-2.3+j*.75,1.05+random.random()*.2))
        o=bpy.context.object;o.name='Indicative shrub';o.scale=(.45,.5,.40+random.random()*.3)
        for c in list(o.users_collection):c.objects.unlink(o)
        land.objects.link(o);o.data.materials.append(green)
overview=bpy.data.objects['Massing overview'];overview.location=(-61,-72,48)
overview.rotation_euler=(Vector((0,0,8))-overview.location).to_track_quat('-Z','Y').to_euler()
overview.data.ortho_scale=80
scene.camera=overview
scene.world.use_nodes=True
bg=scene.world.node_tree.nodes.get('Background');bg.inputs['Color'].default_value=(.62,.75,1.0,1);bg.inputs['Strength'].default_value=.45
sun=next(o for o in scene.objects if o.type=='LIGHT');sun.rotation_euler=(math.radians(28),math.radians(-32),math.radians(-40));sun.data.energy=3
scene.cycles.samples=32;scene.cycles.use_denoising=True
scene.render.resolution_x=1500;scene.render.resolution_y=1100
scene['stage']='03 — Reference-led facade; six apparent levels, dimensions and hidden details estimated'
scene['floor_count']=6;scene['floor_count_evidence']='Five upper window rows plus ground seen at southern end, Dec 2025 Street View'
scene['height_assumed_m']=18
extra='''\nSTAGE 03 — CURRENT MODEL\nSupersedes the earlier five-level interpretation. Southern-end Street View shows five
upper window rows plus ground, so this version uses six levels. Total 18 m height is
still assumed from 3 m floor heights. Balconies are now truly recessed, with pale
projecting fins, solid fascias plus glass railings, framed glazing, timber-toned
ground screens and end-elevation windows. Seven equal facade bays, balcony depths,
window sizes, ground layout and landscaping are modelling estimates. Courtyard facade
and north end are inferred, not verified. Roof obstacle envelopes remain provisional,
now coloured neutral grey. No solar layout or valid sun study is present.
Street reference: southern viewpoint -37.8245223,145.010182, panorama 2iW2qa4Fza-uGbVSxmp6wg,
December 2025; original facade viewpoint -37.8242544,145.0102264.
'''
bpy.data.texts['READ ME — assumptions'].write(extra)
(root/'notes/project-notes.txt').write_text(bpy.data.texts['READ ME — assumptions'].as_string())
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_rotation=overview.rotation_euler.to_quaternion()
            area.spaces.active.region_3d.view_location=(0,0,9)
            area.spaces.active.region_3d.view_distance=85
assert len([o for o in fac.objects if o.name.startswith('Street recessed glazing')])==42
assert round(body.dimensions.z,2)==18
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-03-Facade.blend'))
scene.render.filepath=str(root/'renders/03-facade-overview.png');bpy.ops.render.render(write_still=True)
data=bpy.data.cameras.new('Street facade detail');cam=bpy.data.objects.new(data.name,data);scene.collection.objects.link(cam)
cam.location=(-29,-39,8);cam.rotation_euler=(Vector((-1,-14,9))-cam.location).to_track_quat('-Z','Y').to_euler()
data.type='PERSP';data.lens=36
scene.camera=cam;scene.render.filepath=str(root/'renders/03-street-detail.png');bpy.ops.render.render(write_still=True)
scene.camera=overview
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-03-Facade.blend'))
print('VERIFIED: six levels, 42 street balcony bays, 18 m provisional height; two previews saved.')
