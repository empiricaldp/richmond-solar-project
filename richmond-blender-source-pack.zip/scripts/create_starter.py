import bpy
from pathlib import Path
from mathutils import Quaternion

root = Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.length_unit = 'METERS'
scene.unit_settings.scale_length = 1
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 7.5))
building = bpy.context.object
building.name = 'Building shell — 56.1 x 13.8 m — HEIGHT UNVERIFIED'
building.dimensions = (13.8, 56.1, 15.0)
bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
building['height_status'] = 'PLACEHOLDER: five assumed 3 m levels; floor count and height unverified'
building['footprint_status'] = 'Approximate Google Maps roof envelope, not surveyed wall footprint'
scene['latitude'] = -37.8242866
scene['longitude'] = 145.0103873
scene['orientation_status'] = 'Long axis along local Y; real north alignment not set yet'
scene['traced_roof_area_m2'] = 774.24
notes = '''RICHMOND SOLAR PITCH — STAGE 1 STARTER

Scope: only the long western building beneath the supplied coordinate pin.
Maps: https://maps.app.goo.gl/Mm2rfAXdJpYhfdLk6
Coordinates: -37.8242866, 145.0103873
Google Maps image-based roof trace: length 56.11 m, width approximately 13.79 m,
area 774.24 square metres. Rounded model envelope: 56.1 x 13.8 m.
These are approximate roof measurements, not surveyed wall dimensions.
Street View inspected: December 2025; five apparent above-ground levels,
pending confirmation. Height 15 m is only a modelling placeholder.
The local Y axis follows the building length; real north is NOT yet aligned.

This file contains only the starter shell. It is not a finished building model.
Next: verify floors/height, refine roof shape, add evidence-based rooftop obstacles,
set true orientation, then use company panel specifications for solar layouts.
No usable roof area, panel count, shading or generation has been calculated.
Do not interpret Google imagery copyright year as its capture date.
'''
bpy.data.texts.new('READ ME — assumptions').write(notes)
(root / 'notes' / 'project-notes.txt').write_text(notes)
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type == 'VIEW_3D':
            area.spaces.active.region_3d.view_distance = 85
            area.spaces.active.region_3d.view_location = (0, 0, 7.5)
            area.spaces.active.clip_end = 1000
bpy.ops.wm.save_as_mainfile(filepath=str(root / 'blender' / 'Richmond-Solar-01-Starter.blend'))
assert tuple(round(v, 1) for v in building.dimensions) == (13.8, 56.1, 15.0)
print('VERIFIED: starter dimensions 13.8 x 56.1 x 15.0 m; file saved.')
