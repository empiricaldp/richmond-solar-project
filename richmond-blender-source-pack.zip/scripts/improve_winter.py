import bpy,sys,math,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.props import BoolProperty,FloatProperty,PointerProperty
root=Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch');sys.path.insert(0,str(root/'scripts'));import sun_calc
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-05-Sun-Study.blend'))
scene=bpy.context.scene
class StudySunProperties(bpy.types.PropertyGroup):
    use_refraction:BoolProperty(default=True)
    north_offset:FloatProperty(default=-math.radians(7.7))
bpy.utils.register_class(StudySunProperties);bpy.types.Scene.sun_pos_properties=PointerProperty(type=StudySunProperties)
scene.sun_pos_properties.north_offset=-math.radians(7.7)
W,L,T=1.134,1.762,math.radians(10);C,S=math.cos(T),math.sin(T);Z=18.30+L*S/2
zones=json.loads((root/'notes/obstacle-envelopes.json').read_text())
blocked=[(x-w/2-.5,x+w/2+.5,y-l/2-.5,y+l/2+.5) for _,x,y,w,l,h in zones]+[(-5.1,-3.9,-27.05,27.05),(-5.1,5.9,-.6,.6),(-5.1,5.9,12.4,13.6),(-5.1,5.9,-15.6,-14.4)]
def overlap(a,b):return a[0]<b[1]-1e-8 and a[1]>b[0]+1e-8 and a[2]<b[3]-1e-8 and a[3]>b[2]+1e-8
def rect(x,y):return(x-W/2,x+W/2,y-L*C/2,y+L*C/2)
fixed=list(bpy.data.collections['04 Obstacle envelopes — position and size approximate'].objects)+[o for o in scene.objects if o.name.startswith('Parapet')]+list(bpy.data.collections['08 Neighbour massing — approximate footprints and heights'].objects)
bpy.context.view_layer.update();fixed_v=[];fixed_f=[]
for o in fixed:
    n=len(fixed_v);fixed_v.extend(o.matrix_world@v.co for v in o.data.vertices);fixed_f.extend(tuple(n+i for i in p.vertices) for p in o.data.polygons)
def panel_tree(points):
    v=list(fixed_v);f=list(fixed_f)
    for x,y in points:
        n=len(v)
        for px,py in [(-W/2,-L/2),(W/2,-L/2),(W/2,L/2),(-W/2,L/2)]:v.append(Vector((x+px,y+C*py,Z-S*py+.025)))
        f.append((n,n+1,n+2,n+3))
    return BVHTree.FromPolygons(v,f)
normal=Vector((0,S,C))
def directions(month,day,offset,hours):
    arr=[]
    for h in hours:
        az,el=sun_calc.get_sun_coordinates(h,-37.8242866,145.0103873,-offset,month,day,2026)
        d=sun_calc.get_sun_vector(az,el);arr.append((h,d,max(0,normal.dot(d))))
    return arr
winter=directions(6,21,10,[9+i*.5 for i in range(15)])
def evaluate(points,dirs,nx=2,ny=3):
    bvh=panel_tree(points);samples=[Vector((x+(-.5+(i+.5)/nx)*1.10,y+C*(-.5+(j+.5)/ny)*1.72,Z-S*(-.5+(j+.5)/ny)*1.72+.07)) for x,y in points for i in range(nx) for j in range(ny)]
    shades=[]
    for h,d,w in dirs:
        fraction=sum(bvh.ray_cast(p,d,300)[0] is not None for p in samples)/len(samples)
        shades.append((h,fraction,w))
    weighted=sum(s*w for _,s,w in shades)/sum(w for _,_,w in shades)
    return dict(panels=len(points),kw=round(len(points)*.44,2),weighted_shade_pct=weighted*100,unshaded_panel_equivalent=len(points)*(1-weighted),times=[dict(hour=h,shade_pct=s*100) for h,s,w in shades])
active=next(c for c in bpy.data.collections if c.name.startswith('PV 50'))
baseline=[(o.location.x,o.location.y) for o in active.objects if o.name.startswith('PV 50-')]
assert len(baseline)==90
base=evaluate(baseline,winter,5,8);best=[]
baseline_tree=panel_tree(baseline)
ranked=[]
for x,y in baseline:
    pts=[Vector((x+(-.5+(i+.5)/5)*1.10,y+C*(-.5+(j+.5)/8)*1.72,Z-S*(-.5+(j+.5)/8)*1.72+.07)) for i in range(5) for j in range(8)]
    loss=sum(w*sum(baseline_tree.ray_cast(p,d,300)[0] is not None for p in pts)/len(pts) for _,d,w in winter)/sum(w for _,_,w in winter)
    ranked.append((loss,(x,y)))
trimmed=[p for _,p in sorted(ranked)[:85]]
trimstats=evaluate(trimmed,winter,5,8)
best.append((trimstats['unshaded_panel_equivalent'],.45,trimmed,trimstats))
for gap in (.45,.55,.65,.75,.90,1.1):
    for ix in range(6):
        for iy in range(6):
            points=[];dx=W+.025;dy=L*C+gap;x=-5.9+W/2+dx*ix/6
            while x+W/2<=5.9+1e-8:
                y=-27.05+L*C/2+dy*iy/6
                while y+L*C/2<=27.05+1e-8:
                    if not any(overlap(rect(x,y),b) for b in blocked):points.append((x,y))
                    y+=dy
                x+=dx
            if len(points)<80:continue
            stats=evaluate(points,winter)
            best.append((stats['unshaded_panel_equivalent'],gap,points,stats))
    print('SEARCH_GAP',gap,flush=True)
best.sort(key=lambda a:a[0],reverse=True)
validated=[]
shortlist=best[:12]+sorted([r for r in best if len(r[2])>=85],key=lambda r:r[3]['weighted_shade_pct'])[:12]
for _,gap,points,_ in shortlist:
    stats=evaluate(points,winter,5,8);validated.append((stats['unshaded_panel_equivalent'],gap,points,stats))
validated.sort(key=lambda a:a[0],reverse=True)
score,gap,points,stats=validated[0]
selection='Higher winter unshaded-panel proxy'
if score<=base['unshaded_panel_equivalent']:
    lower=[r for r in validated if r[3]['weighted_shade_pct']<base['weighted_shade_pct'] and len(r[2])>=85]
    assert lower,'No lower-shade alternative found'
    score,gap,points,stats=min(lower,key=lambda r:r[3]['weighted_shade_pct'])
    selection='Lower-shade alternative with capacity tradeoff; baseline retains better winter unshaded-panel proxy'
for i,(x,y) in enumerate(points):
    assert not any(overlap(rect(x,y),b) for b in blocked)
    assert not any(overlap(rect(x,y),rect(xx,yy)) for xx,yy in points[:i])
summer=directions(12,21,11,[9+i*.5 for i in range(17)])
report=dict(method='Incidence-weighted geometric unshaded-panel proxy, winter 09:00–16:00 every 30 min. Not energy production or electrical loss. Identical planar-panel ray model applied to both layouts.',evaluated_candidates=len(best),row_gap_m=gap,baseline_winter=base,improved_winter=stats,baseline_summer=evaluate(baseline,summer,5,8),improved_summer=evaluate(points,summer,5,8),assumptions='Same estimated roof/obstacle/neighbour geometry, 7.7 degree north alignment, 10 degree panel tilt, 440W panels, 1m edge, 0.5m obstacle clearance and reserved access strips. No verified access connections, engineering or electrical design.')
report['selection_reason']=selection
(root/'notes/winter-layout-comparison.json').write_text(json.dumps(report,indent=2))
new=bpy.data.collections.new(f'PV winter revised — {len(points)} panels');scene.collection.children.link(new)
for c in bpy.data.collections:
    if c.name.startswith('PV '):c.hide_render=c.hide_viewport=(c!=new)
prototype=next(o for o in active.objects if o.name.startswith('PV 50-'))
glass=next(o for o in active.objects if o.name.startswith('Module glass'))
for i,(x,y) in enumerate(points):
    for template,label,zoff,yoff in [(prototype,'Panel',0,0),(glass,'Glass',C*.018,S*.018)]:
        o=template.copy();o.data=template.data;new.objects.link(o);o.name=f'{label} revised {i+1:03}';o.location=(x,y+yoff,Z+zoff)
        o['rated_watts']=440 if label=='Panel' else 0
    # Support rails use the baseline geometry, re-positioned to this panel.
    rail=next(o for o in active.objects if o.name.startswith('Concept support rail'))
    for yy in (-L*.31,L*.31):
        o=rail.copy();o.data=rail.data;new.objects.link(o);o.location=(x,y+yy*C,Z-S*yy-.05)
scene['current_layout_panels']=len(points);scene['current_layout_kw']=len(points)*.44
scene['current_layout_status']='Winter revised concept; comparison is geometric, not annual yield'
bpy.data.texts.new('WINTER REVISION — comparison').write(json.dumps(report,indent=2))
sun=next(o for o in scene.objects if o.type=='LIGHT');sun.animation_data_clear();sun.data.animation_data_clear()
az,el=sun_calc.get_sun_coordinates(9.5,-37.8242866,145.0103873,-10,6,21,2026)
sun.rotation_euler=sun_calc.get_sun_vector(az,el).to_track_quat('Z','Y').to_euler();sun.data.energy=3
scene.camera=bpy.data.objects['Roof plan'];scene.render.resolution_x=700;scene.render.resolution_y=1100;scene.cycles.samples=12
scene.render.filepath=str(root/'renders/06-winter-revised.png');bpy.ops.render.render(write_still=True)
new.hide_render=True;active.hide_render=False
scene.render.filepath=str(root/'renders/06-winter-baseline.png');bpy.ops.render.render(write_still=True)
new.hide_render=False;active.hide_render=True
scene.camera=bpy.data.objects['Massing overview']
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-06-Winter-Layout.blend'))
print('COMPARISON',json.dumps(report),flush=True)
