import bpy, math, json
from pathlib import Path
from mathutils import Vector

root = Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-01-Starter.blend'))
scene=bpy.context.scene
def material(name, color, metallic=0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1)
    m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1)
    bs.inputs['Roughness'].default_value=.6; bs.inputs['Metallic'].default_value=metallic
    return m
cream=material('Warm white facade',(.72,.70,.65))
dark=material('Window and recess charcoal',(.055,.085,.105))
roof=material('Light roof membrane',(.53,.59,.62))
orange=material('Estimated rooftop obstacle envelopes',(.85,.30,.075))
ground=material('Context ground',(.14,.18,.20))
def collection(name):
    c=bpy.data.collections.new(name); scene.collection.children.link(c); return c
facade=collection('02 Facade — illustrative layout, five assumed levels')
roofs=collection('03 Roof — parapet height assumed')
obstacles=collection('04 Obstacle envelopes — position and size approximate')
presentation=collection('05 Presentation')
def box(name, pos, dims, mat, col):
    bpy.ops.mesh.primitive_cube_add(size=1,location=pos)
    o=bpy.context.object; o.name=name; o.dimensions=dims
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    for c in list(o.users_collection): c.objects.unlink(o)
    col.objects.link(o); o.data.materials.append(mat)
    return o
body=next(o for o in scene.objects if o.type=='MESH')
body.data.materials.append(cream)
# The roof envelope is retained. Facade detailing is illustrative, not surveyed.
for side in (-1,1):
    for floor in range(5):
        z=floor*3
        box(f'Level {floor+1} recessed glazing side {side}',(side*6.905,0,z+1.7),(.04,54,1.85),dark,facade)
        box(f'Level {floor+1} balcony band side {side}',(side*6.95,0,z+.9),(.20,56.1,.70),cream,facade)
    for y in (-27.8,-18.5,-9.3,0,9.3,18.5,27.8):
        box('Vertical facade divider',(side*7.0,y,7.5),(.25,.30,15),cream,facade)
box('Roof surface',(0,0,15.025),(13.8,56.1,.05),roof,roofs)
for x in (-6.8,6.8): box('Parapet — 0.6 m assumed',(x,0,15.3),(.2,56.1,.6),cream,roofs)
for y in (-27.95,27.95): box('Parapet — 0.6 m assumed',(0,y,15.3),(13.8,.2,.6),cream,roofs)
# Broad envelopes traced qualitatively from satellite view, not asserted equipment identities.
zones=[
 ('O01 north-east raised enclosure',4.7,13.0,3.0,5.3,2.0),
 ('O02 south-east raised enclosure',4.6,-15.0,3.8,5.5,2.0),
 ('O03 north equipment row',-1.0,21.0,1.8,6.0,1.0),
 ('O04 upper-middle equipment row',-1.0,4.8,2.0,6.5,1.0),
 ('O05 lower-middle equipment row',1.0,-10.0,1.8,4.5,1.0),
 ('O06 south equipment row',-1.0,-18.5,1.8,4.0,1.0),
 ('O07 north service cluster',-1.4,14.0,3.0,3.0,1.0),
 ('O08 south service cluster',-1.5,-13.0,3.0,3.0,1.0),
 ('O09 northern transverse services',.4,9.0,8.0,1.2,.65),
 ('O10 southern transverse services',1.6,-24.0,5.0,1.2,.65),
]
for name,x,y,w,l,h in zones:
    o=box(name,(x,y,15.05+h/2),(w,l,h),orange,obstacles)
    o['evidence']='Approximate satellite interpretation; grouping and dimensions require verification'
    o['height_status']='ASSUMED — not measured'; o['equipment_type']='Unconfirmed'
box('Presentation ground',(0,0,-.25),(110,125,.5),ground,presentation)
def camera(name, location, target, scale):
    data=bpy.data.cameras.new(name); o=bpy.data.objects.new(name,data); presentation.objects.link(o)
    o.location=location; o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    data.type='ORTHO'; data.ortho_scale=scale; return o
hero=camera('Massing overview',(-63,-80,65),(0,0,8),83)
top=camera('Roof plan',(0,0,110),(0,0,0),67)
sun_data=bpy.data.lights.new('Presentation light — NOT a sun study','SUN')
sun=bpy.data.objects.new(sun_data.name,sun_data); presentation.objects.link(sun)
sun.rotation_euler=(math.radians(25),math.radians(-30),math.radians(-25)); sun_data.energy=2.5
if scene.world is None: scene.world=bpy.data.worlds.new('Presentation world')
scene.world.color=(.35,.35,.35)
scene.render.engine='CYCLES'; scene.cycles.samples=24
scene.render.resolution_x=1400; scene.render.resolution_y=1000; scene.render.resolution_percentage=100
scene.camera=hero
scene['stage']='02 — provisional massing and obstacle envelopes, not solar design'
extra='''\nSTAGE 02\nFive levels retained as provisional. Facade rhythm is illustrative, not a measured reconstruction.
Roof parapet height 0.6 m assumed. Orange objects represent ten approximate obstacle/service
envelopes from satellite interpretation. Their grouping, positions, dimensions and heights
are provisional. No equipment is positively identified as a lift room, water tank or AC unit.
No access routes or required setbacks have been established. Do not use this model for panel
capacity, compliance, annual yield or shading conclusions yet. Presentation sun is arbitrary.
Real north alignment and neighbouring buildings remain to be added for a sun study.
'''
bpy.data.texts.get('READ ME — assumptions').write(extra)
(root/'notes/project-notes.txt').write_text(bpy.data.texts.get('READ ME — assumptions').as_string())
(root/'notes/obstacle-envelopes.json').write_text(json.dumps(zones,indent=2))
bpy.ops.object.select_all(action='DESELECT'); body.select_set(True); bpy.context.view_layer.objects.active=body
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_rotation=hero.rotation_euler.to_quaternion()
            area.spaces.active.region_3d.view_distance=85
            area.spaces.active.region_3d.view_location=(0,0,8)
            area.spaces.active.shading.color_type='MATERIAL'
assert len(obstacles.objects)==10
assert all(o.location.z-o.dimensions.z/2>=15 for o in obstacles.objects)
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-02-Massing.blend'))
scene.render.filepath=str(root/'renders/02-massing-preview.png'); bpy.ops.render.render(write_still=True)
scene.camera=top; scene.render.resolution_x=800; scene.render.resolution_y=1400
scene.render.filepath=str(root/'renders/02-roof-obstacles.png'); bpy.ops.render.render(write_still=True)
print('VERIFIED: 10 provisional obstacle envelopes, all above roof; model and previews saved.')
