import bpy, math, sys, json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.props import BoolProperty, FloatProperty, PointerProperty
root=Path('/Users/dhrishitpatel/Desktop/Richmond-Solar-Pitch')
sys.path.insert(0,str(root/'scripts'))
import sun_calc
bpy.ops.wm.open_mainfile(filepath=str(root/'blender/Richmond-Solar-04-Panel-Scenarios.blend'))
scene=bpy.context.scene
class StudySunProperties(bpy.types.PropertyGroup):
    use_refraction:BoolProperty(default=True)
    north_offset:FloatProperty(default=0)
bpy.utils.register_class(StudySunProperties)
bpy.types.Scene.sun_pos_properties=PointerProperty(type=StudySunProperties)
# Local +Y is 7.7 degrees east of geographic north, so true north has local azimuth -7.7.
scene.sun_pos_properties.north_offset=math.radians(-7.7)
scene['north_alignment']='Estimated from north-up satellite roof trace: local +Y = 007.7 degrees true, not surveyed'
def mat(name,col):
    m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True
    m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*col,1);return m
context=bpy.data.collections.new('08 Neighbour massing — approximate footprints and heights');scene.collection.children.link(context)
grey=mat('Unverified neighbouring massing',(.31,.34,.38))
def box(name,x,y,w,l,h):
    xx,yy=w/2,l/2
    mesh=bpy.data.meshes.new(name);mesh.from_pydata([(-xx,-yy,0),(-xx,yy,0),(xx,yy,0),(xx,-yy,0),(-xx,-yy,h),(-xx,yy,h),(xx,yy,h),(xx,-yy,h)],[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])
    o=bpy.data.objects.new(name,mesh);context.objects.link(o);o.location=(x,y,0);mesh.materials.append(grey)
    o['status']='Approximate context block from map; footprint and height unverified'
    return o
neighbours=[box('West townhouses — assumed 9 m',-22,0,12,60,9),box('North-east courtyard wing — assumed 18 m',25,21,29,14,18),box('South-east courtyard wing — assumed 18 m',25,-22,29,14,18),box('East courtyard wing — assumed 18 m',46,0,13,55,18),box('Southern development — assumed 24 m',15,-51,45,28,24)]
sun=next(o for o in scene.objects if o.type=='LIGHT');sun.name='Sun Position calculated — Melbourne local time'
sun.data.angle=math.radians(.53);sun.data.energy=3
scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.13
scene.camera=bpy.data.objects['Roof plan'];scene.camera.location=(0,-2,110);scene.camera.rotation_euler=(0,0,0);scene.camera.data.ortho_scale=66
scene.render.engine='CYCLES';scene.cycles.samples=8;scene.cycles.use_denoising=True
scene.render.resolution_x=560;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.render.fps=2;scene.frame_start=1;scene.frame_end=30
frames=root/'renders/sun-study-frames';frames.mkdir(exist_ok=True)
active=next(c for c in bpy.data.collections if c.name.startswith('PV 50'))
panels=[o for o in active.objects if o.name.startswith('PV 50-')]
assert len(panels)==90
obstacles=list(bpy.data.collections['04 Obstacle envelopes — position and size approximate'].objects)
parapets=[o for o in scene.objects if o.name.startswith('Parapet')]
def tree(objects):
    verts=[];polys=[]
    for o in objects:
        offset=len(verts);verts.extend(o.matrix_world@v.co for v in o.data.vertices)
        polys.extend(tuple(offset+i for i in p.vertices) for p in o.data.polygons)
    return BVHTree.FromPolygons(verts,polys,all_triangles=False)
bpy.context.view_layer.update()
base_objects=obstacles+parapets+list(active.objects)
bvh=tree(base_objects+neighbours);bvh_base=tree(base_objects)
samples=[]
for o in panels:
    for ix in range(5):
        for iy in range(8):samples.append(o.matrix_world@Vector(((-.5+(ix+.5)/5)*1.10,(-.5+(iy+.5)/8)*1.72,.06)))
def shade(t,direction):
    return sum(t.ray_cast(p,direction,300)[0] is not None for p in samples)/len(samples)*100
results=[];frame=0
for season,month,day,zone in [('summer',12,21,-11),('winter',6,21,-10)]:
    for i in range(15):
        frame+=1;hour=8+10*i/14
        az,el=sun_calc.get_sun_coordinates(hour,-37.8242866,145.0103873,zone,month,day,2026)
        direction=sun_calc.get_sun_vector(az,el)
        sun.rotation_euler=direction.to_track_quat('Z','Y').to_euler();sun.keyframe_insert('rotation_euler',frame=frame)
        sun.data.energy=3 if el>0 else 0;sun.data.keyframe_insert('energy',frame=frame)
        scene.timeline_markers.new(f'{season} {int(hour):02}:{round((hour%1)*60):02}',frame=frame)
        row=dict(season=season,date=f'2026-{month:02}-{day:02}',local_hour=hour,utc_offset=-zone,azimuth_true_deg=round((math.degrees(az)+7.7)%360,2),elevation_deg=round(math.degrees(el),2),sampled_panel_area_shaded_pct=round(shade(bvh,direction),2) if el>0 else None,roof_only_shaded_pct=round(shade(bvh_base,direction),2) if el>0 else None,frame=frame)
        results.append(row)
        scene.frame_set(frame);scene.render.filepath=str(frames/f'{season}-{i:02}.png')
        bpy.ops.render.render(write_still=True)
        print('STUDY_FRAME '+json.dumps(row),flush=True)
scene.frame_set(7)
scene['study_scope']='90-panel concept; sampled geometric shadows, NOT electrical or annual energy loss'
notes='''SUN STUDY — PRELIMINARY GEOMETRY
Coordinates -37.8242866, 145.0103873. Official Blender Sun Position calculation module
downloaded from https://raw.githubusercontent.com/blender/blender-addons/main/sun_position/sun_calc.py
The module is used directly; the add-on UI is not installed. Source retained with license header.
Dates 21 December 2026 (UTC+11 AEDT), 21 June 2026 (UTC+10 AEST), 08:00–18:00 local time.
Local building +Y estimated 7.7 degrees east of true north from north-up satellite trace.
Ray tests sample 40 points on each of 90 panels. Percentages are sampled geometric panel
area in direct-beam shade, NOT power loss or annual yield loss. Night values are null.
Includes self-shading, provisional roof obstacles, parapets and five approximate neighbour
blocks. Neighbour heights and footprints are unverified. Roof equipment heights, target
height and north alignment are estimates. Trees and distant obstructions are omitted.
Earlier decorative fins were trimmed to roof level in stage 04; their true roof projection
needs verification. Access origin, continuity and code clearances remain unverified.
Animation frames 1–15 summer and 16–30 winter, at 2 fps; keyframes do not need the module
to play. Do not interpolate between the two seasonal sequences for analysis.
This establishes a reproducible preliminary study, not a validated site solar assessment.
'''
(root/'notes/sun-study-assumptions.txt').write_text(notes)
(root/'notes/sun-study-results.json').write_text(json.dumps(results,indent=2))
bpy.data.texts.new('SUN STUDY — assumptions').write(notes)
bpy.ops.wm.save_as_mainfile(filepath=str(root/'blender/Richmond-Solar-05-Sun-Study.blend'))
print('SUN_STUDY_COMPLETE',flush=True)
